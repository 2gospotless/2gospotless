# 2GoSpotless Website

A custom, mobile-friendly static website for 2GoSpotless.

## Files
- `index.html` — complete website
- `assets/2gospotless-logo.jpg` — uploaded logo

## Important
The Book Now buttons point to:
https://2gospotless.setmore.com/

The site uses your current service names/prices from the Setmore booking page.

## Free hosting
The easiest free option is GitHub Pages:
1. Create a GitHub account.
2. Create a new public repository, e.g. `2gospotless-site`.
3. Upload `index.html` and the `assets` folder.
4. Open Settings → Pages.
5. Select Deploy from branch → `main` → `/ (root)`.
6. Save. GitHub will give you a free website address.

Later, you can connect a custom domain such as `2gospotless.com`.
